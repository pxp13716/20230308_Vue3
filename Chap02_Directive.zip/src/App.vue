<template>
  <!-- View
    2.X에서는 항상 단일 요소(하나의 html의 루트 요소가 있어야 한다)만 
    컴파일 대상이 된다. 3은 없어도 됨 
  -->
  <div class="m-3">
    <!-- 바인딩, 보간법이라 한다. -->
    <h1>{{ title }}</h1>

    <!-- 사용자 정의 컴퍼넌트는 반드시 종료 태그가 있어야 한다 -->
    <A15Currency></A15Currency><br>
    <A14ClassModule></A14ClassModule><br>
    <A13StyleClass></A13StyleClass><br>
    <A12ArrayObject></A12ArrayObject><br>
    <A11Refs></A11Refs><br>
    <A10Form></A10Form><br>
    <A09Event></A09Event><br>
    <A08LifeCycle></A08LifeCycle><br>
    <A07Watch></A07Watch><br>
    <A06Computed></A06Computed><br>
    <A05Method></A05Method><br>
    <A04MakeDOM></A04MakeDOM><br>
    <A03Attribute></A03Attribute><br>
    <A02Binding></A02Binding><br>
    <A01Comp />


    <div>
      this is Template
    </div>
    <div>
      <button v-on:click="changeTitle()">Title</button>
    </div>
  </div>
</template>

<script>
// View-Model
// 외부 view(component) import. 

import A01Comp from './components/A01Component.vue';
import A02Binding from './components/A02Binding.vue';
import A03Attribute from './components/A03Attribute.vue';
import A04MakeDOM from './components/A04MakeDOM.vue';
import A05Method from './components/A05Method.vue';
import A06Computed from './components/A06Computed.vue';
import A07Watch from './components/A07Watch.vue';
import A08LifeCycle from './components/A08LifeCycle.vue';
import A09Event from './components/A09Event.vue';
import A10Form from './components/A10Form.vue';
import A11Refs from './components/A11Refs.vue';
import A12ArrayObject from './components/A12ArrayObject.vue';
import A13StyleClass from './components/A13StyleClass.vue';
import A14ClassModule from './components/A14ClassModule.vue';
import A15Currency from './components/A15Currency.vue';

export default {
  // 사용자 정의 태그 형태로 사용할 컴퍼넌트 등록
  components: { 
    A01Comp, A02Binding, A03Attribute, A04MakeDOM, A05Method,
    A06Computed, A07Watch, A08LifeCycle, A09Event, A10Form,
    A11Refs, A12ArrayObject, A13StyleClass, A14ClassModule, A15Currency, 
  },

  // 내부에서 사용할 변수, 함수 등을 등록
  // reactive value => 값이 변경되면 화면이 변경된 값을 기반으로 리 렌더링 된다
  data: function() {
    return {
      title: 'Chap02 지시자(Directive)'
    }
  },
  computed: {

  },
  watch: {

  },
  methods: {
    changeTitle() {
      // script 내부에서 각 변수(data), 함수(methods)의 참조는 this.XXX 형태
      this.title = 'Hello World';
    }
  }
}
</script>

<style></style>