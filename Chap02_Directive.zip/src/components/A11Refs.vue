<template>
  <h3>A11 Refs</h3>
  <form>
    <div class="input-group">
      <input type="text" class="form-control" name="msg"  ref="inputRef">
      <button type="submit" class="btn btn-danger"  @click.prevent="changeMessage" ref="btnRef">ADD</button>
    </div>
  </form>
  <br>

  <div>
    Message: {{message}}
  </div>  
</template>

<script>
export default {
  data() {
    return {
      message: 'Hello World'
    }
  },
  methods: {
    changeMessage(evt) {
      console.log(evt.target);          // Event를 발생시킨 요소
      console.log(this.$refs.btnRef);   // ref로 참조

      console.log(document.querySelector('input[name="msg"]'));   // JavaScript 방식
      console.log(this.$refs.inputRef);                           // ref로 참조

      // 참조하고자 하는 view의 요소에 ref="중복되지 않는 이름"
      // view-model에서 "this.$refs.이름" 형태로 참조
      // "this.$refs.이름.자바스크립트 명령" => JavaScript 객체

      // 처음 매칭된 요소 1개를 가져온다
      // console.log(document.querySelector('#idName'));
      // console.log(document.querySelector('.className'));
      // console.log(document.querySelector('TagName'));

      // 매칭되는 요소 모두 추출
      // console.log(document.querySelectorAll('button'));
      this.message = this.$refs.inputRef.value;
      this.$refs.inputRef.style.background = 'gray'
    }
  }
}
</script>
