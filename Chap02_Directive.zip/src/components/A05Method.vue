<template>
  <h3>A05 Method</h3>

  <div>
    <h5>1. Method</h5>

    onAdd: <br>
    <br>
    
    Name: {{name}}
    <input type="text" name="name" class="form-control" :value="name" v-on:input="changeString">
    Address: {{address}}
    <input type="text" name="address" class="form-control" :value="address" v-on:input="changeString">
    Num: {{num + 1}}
    <input type="text" name="num" class="form-control" :value="num" v-on:input="changeNumber">
  </div>
  <br>

  <div>
    <h5>2. Computed</h5>
    Nickname: {{ nickname }}<br>
    Computed: {{ computedMethod }}<br>
    Methods: {{ sumMethod() }}<br>
  </div>  
</template>

<script>
export default {
  data() {
    return {
      name: 'NolBu',
      address: 'Seoul',
      num: 10
    }
  },
  methods: {
    changeString(evt) {
      // evt.target => <input type="text" name="name" class="form-control">
      this[evt.target.name] = evt.target.value;
    },
    changeNumber(evt) {
      console.log(typeof evt.target.value);
      let value = Number(evt.target.value);
      if(isNaN(value)) {
        value = '';
        evt.target.value = '';
      }
      this[evt.target.name] = value;
    },
    // 뷰에서 리턴 값으로 사용
    sumMethod() {
      console.log('sumMethod....');
      let total = 0;
      for(let i = 1; i <= this.num; i++) {
        total += i;
      }
      return total;
    }
  },
  // Java의 Getter Method
  // 계산된 속성이라 한다
  // data의 값을 기반으로 새로운 값을 변경(추출)해서 사용하는 경우 사용
  // 정의는 함수 형태로, 참조(사용)은 프로퍼티 형태로 참조한다.
  // 함수 내부에 참조한 this 변수가 변경된 경우만 재 호출된다
  computed: {
    nickname: () => 'HongGilDong',
    computedMethod() {
      console.log('computedMethod....');
      let total = 0;
      for(let i = 1; i <= this.num; i++) {
        total += i;
      }
      return total;
    }
  }
}
</script>
