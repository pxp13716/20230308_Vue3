<template>
  <h3>A07 Watch</h3>

  <div>
    <input type="text" class="form-control" v-model="x"><br>
    <input type="text" class="form-control" v-model="y"><br>
    Total: {{total}}<br >
    <br>

    <input type="text" class="form-control" v-model="name"><br>
    <table class="table">
      <thead>
        <tr><th>NO</th><th>NAME</th><th>TEL</th><th>ADDRESS</th></tr>
      </thead>
      <tbody>
        <tr   v-for="contact in contactList" :key="contact.no">
          <td>{{ contact.no }}</td>
          <td>{{ contact.name }}</td>
          <td>{{ contact.tel }}</td>
          <td>{{ contact.address }}</td>
        </tr>
      </tbody>
    </table>

    <div v-show="isLoading">Loading....</div>
  </div>  
</template>

<script>
const baseURL = 'http://sample.bmaster.kro.kr/contacts_long/search/';

export default {
  data() {
    return {
      x: 10, 
      y: 20,
      total: 0,
      name: '',
      isLoading: false,
      contactList: []
    }
  },
  // data 변수가 변경되면 변경되기 전에 단순한 화면 변경이 아닌 선 처리 작업후 변경이 필요한 경우
  // 정의는 변수명과 동일한 이름으로 정의
  watch: {
    x(newVal, oldVal) {
      console.log(newVal, oldVal);
      // '1' + 10
      this.total = Number(this.x) + Number(this.y);
    },
    y() {
      this.getTotal();
    },
    name(value) {
      if(value.length >= 2) {
        this.getContactList();
      }
    }
  },
  methods: {
    getTotal() {
      this.total = Number(this.x) + Number(this.y);
    },
    getContactList() {
      // console.log('Ajax 실행');
      this.isLoading = true;

      fetch(baseURL + this.name)
        .then(resp => resp.json())
        .then(data => {
          console.log(data);
          this.contactList = data;
          this.isLoading = false;
        })
        .catch( error => console.error(error) )
    }
  },
}
</script>
