<template>
  <h3>A14 Class Module</h3>

  <div :class="$style.one">{{hello}}</div>
  <div :class="[$style.one, $style.two]">{{hello}}</div>
  <div :class="classOne">{{hello}}</div>
  <br>

  <div :class="{ [$style.one]: true, [$style.two]: isChecked}">{{hello}}</div>
  <div :class="{ [classOne]: true }">{{hello}}</div>
  <input type="checkbox"  v-model="isChecked"> Check<br />
  <br>
</template>

<script>
export default {
  data() {
    return {
      hello: 'Hello World!!',
      isChecked: true,
      num: 0,
    }
  },
  computed: {
    classOne() {
      return this.$style.one + ' ' + this.$style.two;
    },
  },
  mounted(){
    console.log(this.$style);
  }
}
</script>

<!-- 클래스 이름을 변수처럼 사용한다. 클래스의 이름은 자동으로 중복되지 않는 Hash 코드가 붙는다 -->
<style module>
    .one { color: orange; }
    .two { font-size: 24pt; }
    .three { font-weight: bold; }
</style>
