<!-- A01Component.vue -->
<template>
  <h3>A01 Component</h3>

  <div>
    Hello {{ name }}
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: 'NolBu',
    }
  }
}
</script>