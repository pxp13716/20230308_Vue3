<template>
  <h3>A04 DOM Directive</h3>
  <br>

  <h5>1. v-show</h5>
  <div    v-show="isChecked">
    css로 숨김 / 보이기 구현. 숨김 / 보이기가 자주 반복되는 경우 사용<br>
    v-show가 있는 엘리먼트는 항상 렌더링 되고 DOM에 남아있다는 점입니다. v-show는 단순히 엘리먼트에 display CSS 속성을 토글합니다.
  </div>
  <br />

  <h5>2. v-if</h5>
  <div    v-if="name === 'nolbu'">
    해당되는 view만 동적으로 생성 / 삭제된다. (자주 변경되지 않는 뷰에 유효)<br>
    v-if 구문은 중단에 다른 태그 없이 연속 구현되어야 한다<br>
    Vue에서는 v-if 디렉티브를 사용하여 조건부 블럭을 작성할 수 있습니다.
  </div>
  <div    v-else-if="name === 'hungbu'">
    v-else-if는 여러번 나올 수 있다.<br>
    v-else-if는 이름에서 알 수 있듯, v-if에 대한 “else if 블록” 역할을 합니다. 또한 여러 개를 사용할 수 있습니다.
  </div>
  <div    v-else>
    v-else 구문도 필요에 따라 정의한다(위 조건을 만족하지 않는 경우 표시할 뷰가 있는 경우)<br>
    v-else 디렉티브를 사용하여 v-if에 대한 “else 블록”을 나타낼 수 있습니다
  </div>
  <br>

  <h5>3. v-for</h5>
  <table class="table">
    <thead>
      <tr>
        <th>No</th>
        <th>Name</th>
        <th>Age</th>
        <th>Kor</th>
        <th>Eng</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(student, index) in data.students" v-bind:key="index">
        <td>{{ index + 1 }}</td>
        <td>{{ student.name }}</td>
        <td>{{ student.age }}</td>
        <td>{{ student.kor }}</td>
        <td>{{ student.eng }}</td>
      </tr>
    </tbody>
  </table>
  <br>

  <table class="table">
    <thead>
      <tr>
        <th>No</th>
        <th>Name</th>
        <th>Age</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="item in data.items" v-bind:key="item.no">
        <td>{{ item.id + 1 }}</td>
        <td>{{ item.name }}</td>
        <td>{{ item.age }}</td>
      </tr>
    </tbody>
  </table>
  <br>

  <div>
    <button class="btn btn-outline-primary btn-sm" v-on:click="isChecked = !isChecked;">Check</button>
    <button class="btn btn-outline-primary btn-sm" v-on:click="name = 'nolbu'">IF</button>
    <button class="btn btn-outline-primary btn-sm" v-on:click="name = 'hungbu'">Else IF</button>
    <button class="btn btn-outline-primary btn-sm" v-on:click="name = 'abc'">Else</button><br>
  </div>  
</template>

<script>
const data = {
  students: [
    { name: 'HongGilDong', age: 20, kor: 100, eng: 80 },
    { name: 'NolBu', age: 50, kor: 90, eng: 90 },
    { name: 'HungBu', age: 40, kor: 70, eng: 60 },
  ],
  items: [
    {id: 0, name: 'NolBu', age: 40},
    {id: 1, name: 'HungBu', age: 30},
    {id: 2, name: 'HangDan', age: 20},
  ]
}

export default {
  data() {
    return {
      data, 
      isChecked: true,
      name: 'nolbu'
    }
  }
}
</script>
