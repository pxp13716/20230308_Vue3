<template>
  <h3>A02 Binding</h3>
  바인딩 식 내부에서는 식만 사용 가능<br>
  <br>

  <div>
    <h5>1. 일반적 바인딩</h5>
    일반적인 단방향 바인딩: {{ name }}<br>
    함수의 리턴값: {{ onAdd(1, 2) }}<br>
    함수의 리턴값: {{ onMin(1, 2) }}<br>
    객체가 존재하면 객체의 없는 요소값 참조는 에러가 아님(undefined)<br>
    Vue에서는 undefined는 화면에 표시되지 않는다<br>
    배열: {{ arr[0] }} / {{ arr[1] }} / {{ arr[2] }}<br>
    객체: {{ user.name }} / {{ user.age }} / {{ user.address }}<br>
  </div>
  <br>

  <div>
    <h5>2. 바인딩 연산</h5>
    바인딩 내부에서 연산자는 사용이 가능하다<br>
    일반적 연산: {{ 1 + 2 }}<br>
    속성 참조: {{ arr.length }}<br>
    속성 참조 연산: {{ arr.length * 100 }}<br>
    비교 연산: {{ arr[0] > 100 }}<br>
    비교 연산: {{ arr[0] > 100 && arr[1] > 100 }}<br>
    삼항 연산: {{ name === '놀부' ? '관리자' : '일반 유저' }}<br>
    삼항 연산: {{ !arr[2] ? '값 없음' : '값이 할당되어 있음' }}<br>
  </div>
  <br>

  <div>
    <h5>3. 바인딩 관련 지시자</h5>
    v가 붙은 속성은 Vue 속성으로 값은 변수명이 된다. 또는 실질적인 값<br>
    v-text: <span v-text="text"></span><br>
    v-text: <span v-text="'NolBu'"></span><br>
    v-html: <span v-html="text"></span><br>
    <!-- 한번 값이 할당되고 난 후 값이 변경되도 뷰는 변경되지 않는다 -->
    v-once: <span v-once>{{ text }}</span><br>
    
    <!-- {{  }}를 문자로 사용해야 하는 경우 -->
    v-pre: <span v-pre>{{ text }}</span><br>
    <br>
    <button   v-on:click="changeText('<b>Good Morning</b>')">Change</button>
    <button   @click="changeText('<b>Good Evening</b>')">Change</button>
    <br>
  </div>

  <div>
    Data에 존재하지 않는 변수: 
    Data에 존재하지 않는 객체: 
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: '놀부',
      arr: [10, 20],
      user: {name: 'HungBu', age: 20},
      text: '<b>Hello World</b>'
    }
  },
  methods: {
    onAdd(x, y) {
      // console.log(this);           // Vue component 자체
      // console.log(this.name);
      return `${x} + ${y} = ${x + y}`;
    },
    onMin: (x, y) => {
      // console.log(this);           // undefined
      // console.log(this.name);      // Error. undefined에 NAME 없음
      return `${x} - ${y} = ${x - y}`;
    },
    changeText(txt) {
      this.text = txt;
    }
  }
}
</script>
