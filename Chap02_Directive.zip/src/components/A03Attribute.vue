<template>
  <h3>A03 Attribute Directive</h3>

  <div >
    <h5>1. 속성 바인딩</h5>
    <!-- 
      data 또는 함수의 리턴 값으로 요소의 속성 값으로 사용하는 경우
      v-bind:속성명="변수명"
      :속성명="변수명"
    -->
    <input type="text" class="form-control"   value="{{ name }}"> <!-- Vue 2.x에서는 에러  -->
    <input type="text" class="form-control"   v-bind:value="name">
    <input type="text" class="form-control"   :value="name">
    <input type="text" :class="'form-control'"   :value="name">
    
    <div  :style="{color: 'orange', background: 'lightgray', padding: '5px', fontWeight: 'bold'}">Hello World</div>
    <div  :style="myStyle">Hello World</div>

    <!-- 속성을 한번에 모두 바인딩 -->
    <input v-bind="attrs">
  </div>
  <br>

  <div >
    <h5>2. 양방향 바인딩</h5>
    <input type="text" class="form-control"   v-model="name">
    <input type="text" class="form-control"   v-model="name">

    <!-- 제약조건 등이 필요하다면 속성과 이벤트를 이용하여 양방향 바인딩을 구현할 수 있다 -->
    <input type="text" class="form-control"   :value="name" v-on:input="changeName">
    Name: {{ name }}
  </div>
  <br>

  <div class="row">
    <div class="col-6">
      <select class="form-control"                v-model="direction">
        <option value="width">Width</option>
        <option value="height">Height</option>
      </select>
    </div>
    <div class="col-6">
      <input type="number" class="form-control"   v-model="size">
    </div>
  </div>
  <br>
  <img src="images/tree.jpg" alt="Tree"   v-bind:[direction]="size">
</template>

<script>
export default {
  data() {
    return {
      name: 'NolBu',
      myStyle: {color: 'orange', background: 'lightgray', padding: '5px', fontWeight: 'bold'},
      attrs: { class: 'form-control', type: 'text', value: 'HungBu'},
      direction: 'width',
      size: 200,
    }
  },
  methods: {
    changeName(evt) {
      // console.log(evt.target);
      let value = Number(evt.target.value);
      if(isNaN(value)) {
        evt.target.value = '';
        value = '';
      }
      this.name = value
    }
  }
}
</script>
