<template>
  <h3>A10 Vue Form Element</h3>
  <br>

  <form>
    Text Field: <span class="orange">{{ sendData.name }} / {{ sendData.name.length }}</span>
    <input type="text" class="form-control"   v-model.trim="sendData.name"><br>

    Number Field: <span class="orange">{{ sendData.age + 1}}</span>
    <input type="number" class="form-control" v-model.number="sendData.age"><br>

    Lazy Field: <span class="orange">{{ sendData.address }}</span>
    <input type="text" class="form-control"   v-model.lazy="sendData.address"><br>

    
    Radio Button: <span class="orange">{{ sendData.gender }}</span><br>
    <input type="radio" name="gender" value="남자"    v-model="sendData.gender">Male
    <input type="radio" name="gender" value="여자"    v-model="sendData.gender">Female
    <input type="radio" name="gender" value="어린이"  v-model="sendData.gender">Children <br>
    <br>

    Single Check: <span class="orange">{{ sendData.check ? '동의' : '동의 안함' }}</span><br>
    <input type="checkbox" name="check"   v-model="sendData.check">Agree<br>
    <br>

    Single Check: <span class="orange">{{ sendData.isCheck === 'OK' ? '동의' : '동의 안함' }}</span><br>
    <input type="checkbox" name="check"   
            v-model="sendData.isCheck" true-value="OK" false-value="NO">Agree<br>
    <br>


    CheckBox: <span class="orange">{{ sendData.fruit.join(' - ') }}</span><br>
    <input type="checkbox" value="apple"    v-model="sendData.fruit">사과,
    <input type="checkbox" value="banana"   v-model="sendData.fruit">바나나,
    <input type="checkbox" value="melon"    v-model="sendData.fruit">멜론<br>
    <br>

    SelectBox: <span class="orange">{{ sendData.lang }}</span><br>
    <select class="form-control"    v-model="sendData.lang">
      <option v-for="item in language" :key="item">{{ item }}</option>
    </select>
    <br>

    SelectBox Multi: <span class="orange">{{ sendData.country.join(' / ') }}</span><br>
    <select class="form-control" multiple   v-model="sendData.country">
      <option v-for="item in currencies" :key="item.name">{{ item.name }}: {{ item.value }}</option>
    </select>
    <br>

    TextArea: <span class="orange">{{ sendData.str }}</span>
    <textarea cols="50" rows="5" class="form-control"     v-model="sendData.str"></textarea>
    <br>


    Radio Button Object Value: <span class="orange">{{ sendData.person }} / {{ sendData.person.age }}</span><br>
    <input type="radio" name="person" :value="{name: 'NolBu', age: 50}"   v-model="sendData.person">놀부
    <input type="radio" name="person" :value="{name: 'Hungbu', age: 40}"  v-model="sendData.person">흥부
    <input type="radio" name="person" :value="{name: 'BangJa', age: 30}"  v-model="sendData.person">방자 <br>
    <br>

    <!-- 위의 v-model이 해 주는 기본 기능 이외의 기능이 필요한 경우 속성과 이벤트를 이용해서 구현 -->
    Text Field: <span class="orange">{{ sendData.txt }} / {{ sendData.txt.length }}</span>
    <input type="text" class="form-control" :value="sendData.txt" @input="changeText"><br>

    <button type="submit"     @click.prevent="sendEvent">SEND</button>
  </form>  
</template>

<script>
export default {
  data() {
    return {
      sendData: {
        name: '',
        age: '',
        address: '',
        gender: '여자',
        check: true,
        isCheck: 'NO',
        fruit: [],
        lang: '',
        country: [],
        str: '',
        person: {},
        txt: '',
      }

      // {"name": "NolBu", "age": 30}
    }
  },
  computed: {
    language: () => ['한국어', '영어', '중국어', '프랑스어', '독일어'],
    currencies: () => [
      {name: 'KRW', value: 0.0072},
      {name: 'USD', value: 1},
      {name: 'CNY', value: 6.89},
      {name: 'EUR', value: 0.987}
    ]
  },
  methods: {
    changeText(evt) {
      // 필요에 따라 제약 조건을 기술
      const value = evt.target.value.trim()
      this.sendData.txt = value;
    },
    sendEvent() {
      // 서버에 전송 로직
      // console.log(this.sendData);

      // JSON
      // JavaScript => JSON 객체로 변경
      const jsonData = JSON.stringify(this.sendData);
      console.log(jsonData);

      // JSON => JavaScript 객체로 변경
      const jsData = JSON.parse(jsonData);
      console.log(jsData);
    }
  },
  
}
</script>

<style scoped>
  .orange {color: orange;}
</style>