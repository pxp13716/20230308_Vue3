<template>
  <h3>A15 Currency</h3>

  Qty: <input type="number" class="form-control"    v-model.number="qty">
  Cost: <input type="number" class="form-control"   v-model.number="cost">
  Country: 
    <select class="form-control"    v-model="inCurr">
      <option v-for="country in countries" :key="country">{{ country }}</option>    
    </select>
  <br>
  <div>Total: {{ qty * cost }}</div>
  <!-- item => [{name: USD, value: 15}, {name: EUR, value: 15.8977}, ...] -->
  <div>Total: <span v-for="item in getTotal" :key="item.name">{{ item.name }}: {{ item.value }}, </span></div>  
</template>

<script>
// EUR => qty * cost * 1 / 0.98

export default {
  data() {
    return {
      qty: 3,
      cost: 5,
      inCurr: 'USD'
    }
  },
  methods: {
    
  },
  computed: {
    countries: () => ['USD', 'EUR', 'KRW'],
    rate: () => ({ 'USD': 1, 'EUR': 0.98, 'KRW': 0.00071 }),
    getTotal() {
      const total = this.countries.map( (item) => {
        const value = (this.qty * this.cost * this.rate[this.inCurr] / this.rate[ item ]).toFixed(2);
        return {name: item, value: value};
      });
      return total;
    }
  }
}
</script>
