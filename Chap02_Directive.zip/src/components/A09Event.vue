<template>
  <h3>A09 Event</h3>

  Num: {{num}}<br>
  <button v-on:click="num++">+1</button>
  <button @click="decrease">-1</button>
  <button @click="decrease()">-1</button>
  <button @click.once="decrease">once</button> <!-- 한번만 실행된다 -->
  
  <!-- alt, ctrl, shift, meta, left, middle, right
    alt 키를 누른 상태에서 클릭했니?
  -->
  <button @click.alt="decrease">Key</button>

  <button @click="increase">Event 1</button>
  <button @click="increaseX(3)">Event2</button>

  <!-- ()가 없으면 묵시적으로 이벤트 객체를 전달한다 -->
  <button @click="increaseEvent">Event 3</button>

  <!-- 호출하는 함수에 매개변수가 없다. 대상 함수는 이벤트 객체를 받아야 함 -->
  <!-- <button @click="increaseEvent()">Event</button> -->

  <!-- 자바스크립트의 event 객체를 vue가 오버라이드한 객체 -->
  <button @click="increaseEvent($event)">Event 4</button>

  <button @click="increaseEventColor($event, 'orange')">Event 5</button>

  <!-- 첫번째 콜백함수는 묵시적으로 이벤트 객체를 주입 받는다 -->
  <button @click="(evt) => increaseEventColor(evt, 'orange')">Event 6</button>
  <button @click="$event => increaseEventColor($event, 'orange')">Event 6</button>
  <br>
  <br>
  
  <div id="container"   @click="outer">
  <div id="inner"       @click="innerOne">ONE</div>
  <div id="inner"       @click.stop="innerTwo">TWO</div> <!-- evt.stopPropagation() -->
  </div>
  <br>
  <br>

  <div>
      <a href="http://www.daum.net"   @click="goDaum">DAUM</a> |
      <a href="http://www.naver.com"  @click.prevent="goNaver">NAVER</a> | <!-- evt.preventDefault(); -->
  </div>
  <br>

  <input type="text" class="form-control"         @keydown="keyUpEvent"><br>
  <input type="text" class="form-control"         @keydown.shift.a="keyEvent01"><br>
  esc: <input type="text" class="form-control"    v-model="name"    @keydown.esc="escEvent"/><br>
  Enter: <input type="text" class="form-control"  v-model="msg"     @keydown.enter="enterEvent"/><br>
</template>

<script>
/* eslint-disable */
export default {
  data() {
    return {
      num: 0,
      name: 'Guest',
      msg: ''
    }
  },
  methods: {
    decrease: function() {
      this.num--;
    },
    increase() {
      this.num += 2;
    },
    increaseX(x) {
      this.num += x;
    },
    increaseEvent(evt) {
      console.log(evt.target);
    },
    increaseEventColor(evt, color) {
      console.log(evt.target);
      evt.target.style.background = color;
    },
    outer(evt) {
      console.log(evt.target);
      console.log(evt.currentTarget);
    },
    innerOne(evt) {
      // bubbling 단계(상위 요소)의 이벤트 모두 취소
      // if(true) {
        evt.stopPropagation();
      // }
      
      console.log(evt.target);
      console.log(evt.currentTarget);
    },
    innerTwo(evt) {
      console.log(evt.target);
      console.log(evt.currentTarget);
    },
    goDaum(evt) {
      // dom이 만들어지면서 기본값으로 설정된 자바스크립트 명령을 취소
      evt.preventDefault();
      console.log('DAUM');
    },
    /* eslint-disable no-unused-vars */
    goNaver(evt) {
      console.log('Naver');
    },
    keyUpEvent(evt) {
      console.log(evt.keyCode, evt.code, evt.key);
      console.log(evt.altKey, evt.shiftKey, evt.altKey, evt.metaKey);
      if(evt.keyCode === 36 && evt.shiftKey) {
        location.assign('http://google.com')
      }
    },
    keyEvent01() {
      location.assign('http://google.com');
    },
    escEvent() {
      this.name = '';
    },
    enterEvent(evt) {
      if(evt.target.value.length < 5) {
        alert('5글자 이상 입력하셔야 합니다')
      } else {
        // 서버에 전송 등...
        console.log(evt.target.value);
      }
    }
  }
}
</script>

<style scoped>
  #container { width: 300px; height: 150px; border: 1px solid gray; display: flex; justify-content: center; align-items: center;}
  #inner { width: 100px; height: 100px; background: orange; padding: 10px; margin: 10px; text-align: center; display: flex; justify-content: center; align-items: center;}
</style>