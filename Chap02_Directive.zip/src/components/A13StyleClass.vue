<template>
  <h3>A13 Style & Class</h3>
    
  <div style="color: orange; font-size: 24pt;">{{hello}}</div>
  <div :style="{color: 'orange', fontSize: '24pt'}">{{hello}}</div>
  <div :style="styleOne">{{hello}}</div>
  <br>

  <h3>Class Binding</h3>

  <div class="one"  v-bind:class="'two'">{{hello}}</div>
  <div class="one"  :class="['two', 'three']">{{hello}}</div>
  <div class="one"  :class="classOne">{{hello}}</div>
  <br>

  <div :class="{'one': true, 'two': true, 'three': check}">{{hello}}</div>
  <div class="one"    :class="{ [classOne]: check}">{{hello}}</div>
  <input type="checkbox" v-model="check"> Check<br />
  <br>

  <input type="text" class="form-control" ref="inputRef" v-model.number="num" :class="checkValue" />  
</template>

<script>
export default {
  data() {
    return {
      hello: 'Hello World!!',
      styleOne: {color: 'orange', fontSize: '24pt'},
      classOne: 'two three',
      check: true,
      num: 0,
    }
  },
  computed: {
    checkValue() {
      // computed는 속성. 즉 data가 생성되는 시점 created(){}에서는 view 요소(template)이 참조 안됨
      // const value = this.$refs.inputRef.value;

      if(this.num < 0 || this.num > 100) return {warning: true}
      else return {warning: false}
    }
  }
}
</script>

<!-- 지역 CSS(즉 이 컴퍼넌트에서만 사용할 수 있는 CSS가 된다) -->
<style scoped>
  .one { color: orange; }
  .two { font-size: 24pt; }
  .three { font-weight: bold; }
  .warning {background-color: orange; color: gray; }
</style>


<!-- 이 프로젝트 전체에서 사용할 수 있는 CSS -->
<style>
  .orange { color: orange; }
</style>
