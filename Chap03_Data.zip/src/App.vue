<template>
  <div class="m-4">
    <h1>Chap03 Data</h1>

    <A05ContactList></A05ContactList><br>
    <A04RefProps></A04RefProps><br>
    <A03Emits></A03Emits><br>
    <A02Props title="A02 Props Comp"></A02Props><br>
    <A01Component></A01Component>
  </div>
</template>

<script>
import A01Component from './components/A01Component.vue';
import A02Props from './components/A02Props.vue';
import A03Emits from './components/A03Emits.vue';
import A04RefProps from './components/A04RefProps.vue';
import A05ContactList from './components/A05ContactList.vue';

export default {
  name: 'App',
  components: {
    A01Component, A02Props, A03Emits, A04RefProps, A05ContactList, 
  }
}
</script>
