import { createApp } from 'vue'
import App from './App.vue'
import 'bootstrap/dist/css/bootstrap.min.css';

// 전역 세팅을 보통 여기서 한다.
const app = createApp(App);
app.config.unwrapInjectedRef = true;
app.mount('#app')
