<template>
  <h3>A10 Slot Name</h3>

  <A10SlotNameChild>
    <!-- name 지정을 안하면 default slot에 모두 모아 표시된다 -->
    <div>처음에 작성</div>

    <!-- 각각 지정한 공간에 배치된다 -->
    <template v-slot:header>Header Content</template>
    <template v-slot:sub>Sub Content</template>
    <template v-slot:content>Content</template>
    <template v-slot:footer>Footer Content</template>

    <div>마지막에 작성</div>
  </A10SlotNameChild>
</template>

<script>
import A10SlotNameChild from './childcomps/A10SlotNameChild.vue'

export default {
  components: { A10SlotNameChild },
  data() {
    return {
      
    }
  }
}
</script>
