<template>
  <h3>A04 Ref Props</h3>  

  <div>
    <button @click="callChildMethod">Call Child Method</button>
    <button @click="callChildEvent">Call Child Event</button>
  </div>
  <br>
  <A04RefPropChild ref="childRef"></A04RefPropChild>
</template>

<script>
import A04RefPropChild from './childcomps/A04RefPropChild.vue'
export default {
  components: { A04RefPropChild },
  data() {
    return {
      
    }
  },
  methods: {
    callChildMethod() {
      // $refs 객체의 주소값을 참조하여 실행하는 형태가 된다
      this.$refs.childRef.changeAge(3000);
      this.$refs.childRef.name = '홍길동';
      this.$refs.childRef.$refs.nameRef.style.background = 'lightgray'
    },
    callChildEvent() {
      this.$refs.childRef.$refs.btnRef.click();
    }
  }
}
</script>
