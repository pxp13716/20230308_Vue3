<template>
  <h3>A09 Slot</h3>

  <A09SlotChild><b>Hello World</b></A09SlotChild>
  <A09SlotChild></A09SlotChild>
</template>

<script>
import A09SlotChild from './childcomps/A09SlotChild.vue'

export default {
  components: { A09SlotChild },
  data() {
    return {
      
    }
  }
}
</script>
