<template>
  <h5>A04 Ref Props Child Component</h5>  

  <div>
    Name: {{ name }}<br>
    <input type="text" class="form-control"   ref="nameRef">
    <input type="text" class="form-control"   :value="age">
    <button   @click="changeName"             ref="btnRef">Click</button>
  </div>
  <br>

</template>

<script>
export default {
  data() {
    return {
      name: 'NolBu',
      age: 30
    }
  },
  methods: {
    changeAge(age) {
      this.age = age;
    },
    changeName() {
      this.name = this.$refs.nameRef.value;
      this.$refs.nameRef.style.color = 'orange';
    }
  }
}
</script>
