<template>
  <h5>A09 Slot Child Component</h5>

  <div>
    <!-- 부모 요소가 전달한 view 요소를 출력하고자 하는 곳에 정의한다 -->
    <slot>기본적으로 표시할 DOM 구현</slot>
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>
