<template>
  <h5>A03 Emits Child Component</h5>  

  하위 컴퍼넌트의 data(어떠한 값)을 상위 컴퍼넌트에 전달<br>
  <div>
    <button   @click="sendNum">Num</button>
    <button   @click="sendObject">Data</button>
  </div>

</template>

<script>
export default {
  // 여기에 지정한 이름은 커스텀 이벤트. 네이트브 이벤트랑 구분하기 위함. 정의하지 않으면 경고
  emits: ['sendNumEvent', 'sendObjEvent'],
  data() {
    return {
      num: 10,
      name: 'NolBu',
      arr: [10, 20],
      user: {name: 'HungBu', age: 20}
    }
  },
  methods: {
    sendNum() {
      // 클릭되면 지정한 사용자 정의 이벤트를 발생시킨다
      // this.$emit('커스텀이벤트명', 전달할값)
      this.$emit('sendNumEvent', this.num);
    },
    sendObject() {
      const data = {
        num: this.num,
        name: this.name,
        arr: this.arr,
        user: this.user
      }
      this.$emit('sendObjEvent', data);
    }
  }
}
</script>
