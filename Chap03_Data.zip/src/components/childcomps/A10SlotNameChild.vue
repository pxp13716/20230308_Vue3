<template>
  <h5>A10 Slot Named</h5>

  <!-- slot은 1개 이상 지정 가능. 이때 name 속성을 기술하여 구분한다.
    name 속성이 없으면 기본 slot이 된다
  -->
  <div class="row card-body">
    <div class="col-12 border">
      <slot name="header">Header 기본값</slot>
    </div>
    <div class="col-4 border">
      <slot name="sub">Sub 기본값</slot>
    </div>
    <div class="col-8 border">
      <slot name="content">content 기본값</slot>
    </div>
    <div class="col-12 border">
      <slot name="footer">footer 기본값</slot>
    </div>

    <div class="col-12">
      <slot>기본값</slot>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>

<style scoped>
  .border { border: 1px solid lightgray; }
</style>