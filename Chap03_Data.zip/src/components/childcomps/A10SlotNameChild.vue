<template>
  <h5>A10 Slot Named</h5>

  <div class="row card-body">
    <div class="col-12 border">
      
    </div>
    <div class="col-4 border">
      
    </div>
    <div class="col-8 border">
      
    </div>
    <div class="col-12 border">
      
    </div>

    <div class="col-12">
      
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>

<style scoped>
  .border { border: 1px solid lightgray; }
</style>