<template>
  <form>
    <div class="input-group">
      <input type="text" class="form-control" ref="searchRef"/>
      <div class="input-group-append">
        <button type="submit" class="btn btn-primary mr-1"    
                        @click.prevent="sendKeyword">Submit</button>
      </div>
    </div>  
  </form>
</template>

<script>
export default {
  methods: {
    sendKeyword() {
      const value = this.$refs.searchRef.value;
      this.$emit('searchEvent', value);
    }
  }
}
</script>
