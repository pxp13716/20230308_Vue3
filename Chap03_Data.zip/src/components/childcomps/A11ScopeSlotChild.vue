<template>
  <h3>A11 Scoped Slot</h3>

  <div>
    자식 컴퍼넌트의 데이터를 부모 컴퍼넌트에서 조작.
  </div>

  <div>
    <input type="text" class="form-control" v-model.number="kor">
    <input type="text" class="form-control" v-model.number="eng">
  </div>

  <!-- slot props라 한다. name 속성은 값으로 사용할 수 없다 -->
  <slot nickname="디폴트" :kor="kor" :eng="eng" :user="user" :changeKor="changeKor"></slot>
  <slot name="jumsu"  nickname="점수" :kor="kor" :eng="eng" :user="user" :changeKor="changeKor"></slot>

</template>

<script>
export default {
  data() {
    return {
      kor: 90,
      eng: 70,
      user: {name: 'HungBu', age: 20, address: 'Busan'},
    }
  },
  methods: {
    changeKor(kor) {
      this.kor = kor;
      this.user.name = 'BangJa';
    }
  }
}
</script>
