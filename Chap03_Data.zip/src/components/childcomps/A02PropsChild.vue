<template>
  <h5>A02 Props Child Component</h5>

  <div>
    <!-- props로 넘어오는 값은 참조만 가능한 변수다 -->
    Name: {{ name }}<br>
    Age: {{ age }}<br>
    Address: {{ address }}<br>
    Array: {{ array[0] }} / {{ array[1] }} / {{ array[2] }}<br>
    User: {{ user.name }} / {{ user.age }} / {{ user.address }}<br>
    Check: {{ isChecked ? 'T' : 'F' }}<br>
    onAdd: {{ onAdd(10, 20) }}<br>
    Title: {{ title }}
  </div>
</template>

<script>
export default {
  // 부모가 전달한 속성을 값으로 받아 사용
  // props: ['name', 'age', 'address', 'array', 'user', 'isChecked', 'onAdd', 'title'],
  
  props: {
    name: { type: String, default: 'Unknown', required: true},
    age: { type: [Number, String], default: 0},
    address: { type: String },
    array: {
      type: Array,
      // 객체는 함수 형태로 디폴트 값을 설정해야 한다
      // validator의 조건과 매칭될 필요가 있다
      default: () => ['', ''],
      // value가 넘어오는 값 => [10,20]
      validator: (value) => {
        if(value.length >= 2) return true;
        else return false;
      }
    },
    user: {
      type: Object,
      // validator의 조건과 매칭될 필요가 있다
      default: () => ({name: 'unknown', age: '값없음'}),
      validator: (value) => {
        // 값이 있으면 true
        // 값이 없거나 값이 undefined, null, '', 0, NaN 인 경우 false로 취급
        if(value.name && value.age) return true;
        else return false;
      },
    },
    isChecked: { type: Boolean },
    onAdd: {
      type: Function,
      // default자체가 기본 값이 된다
      default(x, y) {
        return x + y;
      },
      validator: (callback) => typeof callback(1, 2) === 'string',
    },
    title: { type: String }
  },
  
  
  data() {
    return {
      
    }
  }
}
</script>
