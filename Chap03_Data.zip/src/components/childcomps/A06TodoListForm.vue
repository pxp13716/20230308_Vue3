<template>
  <form>
    <div class="input-group">
      <input type="text" class="form-control"     ref="todoRef"/>
      <div class="input-group-append">
        <button type="submit" class="btn btn-primary mr-1" @click.prevent="sendData">Submit</button>
      </div>
    </div>  
  </form>
</template>

<script>
export default {
  props: ['addTodo'],
  data() {
    return {
      
    }
  },
  methods: {
    sendData() {
      const value = this.$refs.todoRef.value;
      if(value.trim().length !== 0) {
        this.addTodo(value);
        this.$refs.todoRef.value = '';  // 값 비우고
        this.$refs.todoRef.focus();     // 커서 위치 시켜라
      }
    }
  }
}
</script>
