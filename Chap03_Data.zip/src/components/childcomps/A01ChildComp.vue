<template>
  <h3>A01 Child Component</h3>
</template>

<script>
export default {
  
}
</script>