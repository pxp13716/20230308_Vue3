<template>
  <h3>A02 Props / {{ title }}</h3>

  <!-- 하위 컴퍼넌트에게 값 전달은 속성으로 전달한다 -->
  <A02PropsChild 
    name="NolBu"
    :age="30"
    :address="address"
    :array="arr"
    :user="user"
    :isChecked="true"
    :onAdd="onAdd"
    :title="title">
  </A02PropsChild>
</template>

<script>
import A02PropsChild from './childcomps/A02PropsChild.vue';

export default {
  props: ['title'],
  components: { A02PropsChild },
  data() {
    return {
      address: 'Seoul',
      arr: [10, 20],
      user: {name: 'HungBu', age: 10}
    }
  },
  methods: {
    onAdd(x, y) {
      return `${x} + ${y} = ${x + y}`
    }
  }
}
</script>
