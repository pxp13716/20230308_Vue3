<template>
  <h3>A03 Emits</h3>  

  <div>
    Counter: {{ num }}<br>
    <br>
    Object: <br>
    {{ data.num }} / {{ data.name }} / {{ data.arr && data.arr[0] }} /
    {{ data.user && data.user.name }}
  </div>

  <hr>

  <!-- 이 자식에서 지정한 이벤트(sendNumEvent, sendObjEvent)가 발생되면 실행할 명령 지정 -->
  <A03EmitChild @sendNumEvent="getNumber" @sendObjEvent="getObject"></A03EmitChild>
</template>

<script>
import A03EmitChild from './childcomps/A03EmitChild.vue';
export default {
  components: { A03EmitChild },
  data() {
    return {
      num: 0,
      data: {},
      // 아래와 같이 정의하면 view에서 {{ data.user && data.user.name }} 형태를 {{ data.user.name }} 사용해도 된다
      // data: {num, '', name: '', arr: [], user: {}}
    }
  },
  methods: {
    getNumber(evt) {
      // console.log(evt);      // evt 자체가 전달한 값이다
      this.num = evt;
    },
    getObject(evt) {
      // console.log(evt);
      this.data = evt;
    }
  }
}
</script>
