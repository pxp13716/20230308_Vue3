<template>
  <h3>A05 ContactList</h3>

  <A05ContactForm     @searchEvent="getKeyword"></A05ContactForm>
  <A05ContactList     :searchData="searchData"></A05ContactList>
</template>

<script>
import A05ContactForm from './childcomps/A05ContactForm.vue'
import A05ContactList from './childcomps/A05ContactList.vue'

const baseURL = 'https://sample.bmaster.kro.kr/contacts_long/search/'

export default {
  components: { A05ContactForm, A05ContactList },
  data() {
    return {
      searchData: [],
    }
  },
  methods: {
    getKeyword(evt) {
      if(evt.length >= 2){
        fetch(baseURL + evt)
          .then(resp => resp.json())
          .then(data => {
            // console.log(data);
            this.searchData = data;
          })
          .catch(error => console.error(error) )
      }
      

    }
  }
}
</script>
