<template>
  <h3>A06 TodoList</h3>

  <A06TodoListForm  :addTodo="addTodo"></A06TodoListForm>
  <A06TodoListTable :todoList="todoList" :updateTodo="updateTodo" :deleteTodo="deleteTodo"></A06TodoListTable>
</template>

<script>
import A06TodoListForm from './childcomps/A06TodoListForm.vue'
import A06TodoListTable from './childcomps/A06TodoListTable.vue'

const todoList = [
  { id: 1, text: '첫 번째 할 일', done: true },
  { id: 2, text: '두 번째 할 일', done: false },
  { id: 3, text: '세 번째 할 일', done: false },
];

export default {
  components: { A06TodoListForm, A06TodoListTable },
  data() {
    return {
      todoList,
      id: 4,
    }
  },
  methods: {
    updateTodo(id) {
      // 넘어온 값은 id. 변경값은 배열의 index라 차이가 발생.
      // 실질적인 index 번호를 찾기위한 메서드
      // const index = this.todoList.findIndex(todo => todo.id === id);
      // this.todoList[index].done = ! this.todoList[index].done;

      // 실질적인 객체(요소)를 반환
      const todo = this.todoList.find(todo => todo.id === id);
      todo.done = !todo.done;
    },
    deleteTodo(id) {
      const index = this.todoList.findIndex(todo => todo.id === id);
      this.todoList.splice(index, 1);
    },
    addTodo(text) {
      const todo = { id: this.id++, text, done: false };
      this.todoList.push(todo);
    }
  }
}
</script>
