<template>
  <h3>A11 Scoped Slot</h3>

  <A11ScopeSlotChild>
    <!-- one이 slot에서 전달한 속성 값을 참조하는 참조 변수다. 이름은 중복되지 않는 임의의 이름으로 기술 -->
    <template v-slot="one">
      Name: {{ one.nickname }}<br>
      Jumsu: {{ one.kor }} / {{ one.eng }}<br>
      User: {{ one.user.name }} / {{ one.user.age }}<br>
      <button class="btn btn-primary"   @click="one.changeKor(300)">Change</button>

      <hr>
    </template>
    
    <!-- template 사이에 일반 DOM 요소를 배치하면 에러 발생 -->
    <!-- <br> -->

    <template v-slot:jumsu="two">
      Name: {{ two.nickname }}<br>
      Jumsu: {{ two.kor }} / {{ two.eng }}<br>
      User: {{ two.user.name }} / {{ two.user.age }}<br>
      <button class="btn btn-primary"   @click="two.changeKor(300)">Change</button>
    </template>
  </A11ScopeSlotChild>


  <A11ScopeSlotChild>
    <!-- one이 slot에서 전달한 속성 값을 참조하는 참조 변수다. 이름은 중복되지 않는 임의의 이름으로 기술 -->
    <template v-slot="one">
      Name: {{ one.nickname }}<br>
      Jumsu: {{ one.kor }} / {{ one.eng }}<br>
      User: {{ one.user.name }} / {{ one.user.age }}<br>
      <button class="btn btn-primary"   @click="one.changeKor(300)">Change</button>

      <hr>
    </template>
    
    <!-- template 사이에 일반 DOM 요소를 배치하면 에러 발생 -->
    <!-- <br> -->

    <template v-slot:jumsu="two">
      Name: {{ two.nickname }}<br>
      Jumsu: {{ two.kor }} / {{ two.eng }}<br>
      User: {{ two.user.name }} / {{ two.user.age }}<br>
      <button class="btn btn-primary"   @click="two.changeKor(300)">Change</button>
    </template>
  </A11ScopeSlotChild>

</template>

<script>
import A11ScopeSlotChild from './childcomps/A11ScopeSlotChild.vue'

export default {
  components: { A11ScopeSlotChild },
  data() {
    return {
      
    }
  }
}
</script>
