<template>
  <h3>A11 Scoped Slot</h3>

  <A11ScopeSlotChild></A11ScopeSlotChild>
</template>

<script>
import A11ScopeSlotChild from './childcomps/A11ScopeSlotChild.vue'

export default {
  components: { A11ScopeSlotChild },
  data() {
    return {
      
    }
  }
}
</script>
