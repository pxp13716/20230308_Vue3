<template>
  <h3>A01 Component</h3>
  
  <A01ChildComp></A01ChildComp>
</template>

<script>
import A01ChildComp from './childcomps/A01ChildComp.vue';
export default {
  components: { A01ChildComp },
  data() {
    return {
      
    }
  }
}
</script>
