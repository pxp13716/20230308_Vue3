const todoList = {
  namespaced: true,
  state: {
    todoList: [
      { id: 1, text: '첫 번째 할 일', done: true },
      { id: 2, text: '두 번째 할 일', done: false },
      { id: 3, text: '세 번째 할 일', done: false },
    ],
    id: 4
  },
  mutations: {
    updateTodo(state, payload) {
      const todo = state.todoList.find(todo => todo.id === payload);
      todo.done = !todo.done;
    },
    deleteTodo(state, payload) {
      console.log(payload);
      const index = state.todoList.findIndex(todo => todo.id === payload);
      state.todoList.splice(index, 1);
    },
    addTodo(state, payload) {
      const todo = { id: state.id++, text: payload, done: false };
      state.todoList.push(todo);
    }
  },
  actions: {

  }
}
export default todoList;
