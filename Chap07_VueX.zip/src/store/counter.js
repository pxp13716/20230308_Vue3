
export default {
  namespaced: true,
  state: {
    moduleName: 'Counter',
    cnt: 0,
    contacts: [
      { no: 1001, name: '김유신', tel: '010-1212-3331', address: '경주' },
      { no: 1002, name: '장보고', tel: '010-1212-3332', address: '청해진' },
      { no: 1003, name: '관창', tel: '010-1212-3333', address: '황산벌' },
    ]
  },
  mutations: {
    increase(state, payload) {
      state.cnt = state.cnt + payload;
    },
    decrease(state) {
      state.cnt = state.cnt - 1;
    },
  },
  actions: {
    increaseAction(action, value) {
      setTimeout(() => {
        const result = Number(value);
        action.commit('increase', result);
      }, 1000)
    }
  },
  getters: {
    contactLength: (state) => state.contacts.length,
    getItem: (state) => state.contacts[0],
    getItemIndex: (state) => (no) => state.contacts.find(item => item.no === Number(no))
  },
  // 하위 모듈 정의
  modules: {

  }
}