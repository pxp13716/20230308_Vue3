import { createStore } from 'vuex';

// main.js에 라우터 처럼 등록이 우선되어야 함
const store = new createStore({
  // 참조할 변수를 정의 (읽기 전용). 값은 mutations에 의해 변경되어야 한다.
  state: {
    moduleName: 'Counter',
    cnt: 0,
    contacts: [
      { no: 1001, name: '김유신', tel: '010-1212-3331', address: '경주' },
      { no: 1002, name: '장보고', tel: '010-1212-3332', address: '청해진' },
      { no: 1003, name: '관창', tel: '010-1212-3333', address: '황산벌' },
    ]
  },
  // state에 정의된 변수를 수정하는 메서드
  // component에서는 commit 명령으로 호출해서 사용
  mutations: {
    // state => 위의 state
    // payload => commit으로 호출되면서 전달되는 매개변수 값
    increase(state, payload) {
      state.cnt = state.cnt + payload;
    },
    decrease(state) {
      state.cnt = state.cnt - 1;
    },
  },
  // 시간이 걸리는 처리 작업. mutations의 메서드를 호출한다
  // 또는 state의 값을 변경하기 전 사전 처리 작업
  actions: {
    // action은 mutation을 참조할 수 있는 commit을 지원
    // value => 사용자가 전달한 값(매개변수 값)
    // 호출은 dispatch로 한다
    increaseAction(action, value) {
      setTimeout(() => {
        const result = Number(value);
        action.commit('increase', result);
      }, 1000)
    }
  },
  // component의 computed와 같은 작업
  // state의 값을 기반으로 새로운 값이 필요한 경우
  getters: {
    contactLength: (state) => state.contacts.length,
    getItem: (state) => state.contacts[0],
    getItemIndex: (state) => (no) => state.contacts.find(item => item.no === Number(no))
  },
  // 하위 모듈 정의
  modules: {
    // namespaced: true,
    // name: 'todoList',
    // state: {},
    // mutations: {}
  }
});
export default store;
