import { createStore } from 'vuex';
import counter from './counter';
import todoList from './todoList';

// main.js에 라우터 처럼 등록이 우선되어야 함
const store = new createStore({
  modules: {
    // 앞의 이름 counter가 moduleName으로 호출
    counter: counter,
    todos: todoList,
  }
});
export default store;
