import { createApp } from 'vue'
import App from './App.vue'
import store from './store';
import 'bootstrap/dist/css/bootstrap.css'

const app = createApp(App);
app.use(store);                   // 스토어 등록. 단일 스토어만 가능하다(1개만 가능)
app.config.unwrapInjectedRef = true;
app.mount('#app')
