<template>
  <form>
    <div class="input-group">
      <input type="text" class="form-control"     ref="todoRef"/>
      <div class="input-group-append">
          <button type="submit" class="btn btn-primary mr-1"  @click.prevent="sendData">Submit</button>
      </div>
    </div>  
  </form>
</template>

<script>
export default {
  methods: {
    sendData() {
      const value = this.$refs.todoRef.value;
      if(value.trim().length !== 0) {
        this.$store.commit('todos/addTodo', value);
        this.$refs.todoRef.value = '';
        this.$refs.todoRef.focus();
      }
    }
  }
}
</script>

<style scoped>

</style>