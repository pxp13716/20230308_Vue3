<template>
  <div>
    <h3>Counter</h3>

    <div>
      Size: {{ size }}<br>
      Item: {{ item.name }}<br>
      Index: {{ itemIndex.name }}
    </div>

    <div>
      {{ name }}: {{ cnt }}<br>
      <button   @click="plus">+</button>
      <button   @click="min">-</button>
    </div>
</div>
</template>

<script>
export default {
  computed: {

    // state 값 참조
    name() {
      return this.$store.state.counter.moduleName;
    },
    cnt() {
      return this.$store.state.counter.cnt;
    },

    // getters 값 참조
    size() {
      return this.$store.getters['counter/contactLength'];
    },
    item() {
      return this.$store.getters['counter/getItem'];
    },
    itemIndex() {
      // 넘어오는 값이 함수다.
      const result = this.$store.getters['counter/getItemIndex']
      return result(1002)
    }
  },
  methods: {
    plus() {
      // mutations 메서드 호출
      // this.$store.commit('increase', 2)                // mutations 호출
      this.$store.dispatch('counter/increaseAction', 3);  // actions 호출
    },
    min() {
      this.$store.commit('counter/decrease');
    },
  },
  created() {
    // console.log(this.$store);
  }
}
</script>