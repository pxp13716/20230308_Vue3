import { arr, user, onAdd, age } from './A01ExportOne';
import two from './A01ExportTwo';
import { longNameVar as long, address } from './A01ExportTwo';

import $ from 'jquery'

console.log(arr[0]);
console.log(user.name);

const app = document.getElementById('app');

// JavaScript DOM 생성
const div = document.createElement('h3');      // <div></div>
const text = document.createTextNode(address);  // 'Seoul'

div.appendChild(text);  // <div>Seoul</div>
app.appendChild(div);   // <div><div>Seoul</div></div>
