// A01Import.js
// 개별 export는 {}로 묶고 export 한 변수, 함수명과 동일한 이름으로 로드해서 사용
import { arr, user, onAdd } from './A01ExportOne.js';

// default가 붙으면 {} 없이 임의의 이름으로 정의 가능
// as로 이름 변경 가능
import two, { address, longNameVar as long } from './A01ExportTwo.js';

// 위와 같이 묶어서 사용도 가능
// import { address } from './A01ExportTwo.js';

console.log('A01Import.js');
console.log(window);
console.log('------------- start -------------');

console.log(arr[1]);
console.log(user.name);
user.age = 3000;
console.log(user.age);
console.log(onAdd(10, 20));
console.log('');

console.log(two.y);
console.log(two.onMin());
console.log(two.getX());
console.log(address);
console.log(long);
