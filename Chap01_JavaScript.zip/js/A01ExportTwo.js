// A01ExportTwo.js

const app = (function () {
  const x = 10;
  const y = 20;

  const onMin = () => `${x} - ${y} = ${x - y}`;
  const getX = () => x;

  return {
    y, onMin, getX
  }
})();

const address = 'Seoul';
const longNameVar = 'Long';

// 문서중에 꼭 1개의 요소만 지정 가능. 2개 안됨
export default app;
export { address, longNameVar };