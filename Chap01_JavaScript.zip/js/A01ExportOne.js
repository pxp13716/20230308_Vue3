// A01ExportOne.js

export const age = 30;
const arr = [10, 20];

// age = 40;      // Error
arr[0] = 100;
// arr = [];      // Error

const user = { name: 'foo', age: 20 }
user.name = 'bar';

const onAdd = (x, y) => `${x} + ${y} = ${x + y}`;

export { arr, user, onAdd }