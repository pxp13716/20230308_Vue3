// A02Arrow.js
const onAdd = (x, y) => `${x} + ${y} = ${x + y}`;
let x = 10;
const y = 20;

const [a, b] = [10, 20];

class Foo {
  #bar = "bar";

  test(obj) {
    return #bar in obj;
  }
}
