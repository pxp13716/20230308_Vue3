<template>
  <h3>A07 Warn</h3>

  {{name}}
</template>

<script>
export default {
  data() {
    return {
      isChecked: false
    }
  },
}
</script>