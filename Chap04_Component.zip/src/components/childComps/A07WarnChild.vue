<template>
  <div v-if="isError">
    <h5>Child Component</h5>
  </div>  
</template>

<script>
export default {
  
}
</script>
