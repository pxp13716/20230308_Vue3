<template>
  <div>
    <h3>A04 Props</h3>

    <div>
        Name: {{ name }}<br>
        No: {{ no }}<br>
        Person: {{ person.name }}<br>
    </div>
  </div>
</template>

<script>
import contactlist from './data/ContactList';

export default {
  // params로 넘긴 값을 props로 받는다. 
  // 라우터에 props: true가 걸려 있어야 사용 가능
  props: ['no', 'name'],
  data() {
    return {
      contacts: contactlist.contacts,
    }
  },
  computed: {
    person() {
      // 넘어오는 값은 string
      return this.contacts.find(item => item.no === Number(this.no))
    }
  },
}
</script>
