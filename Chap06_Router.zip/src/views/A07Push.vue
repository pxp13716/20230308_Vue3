<template>
  <div>
    <h3>A07 Push</h3>

    <div>
      <button   @click="back">BACK</button>
      <button   @click="forward">FORWARD</button>
      <button   @click="goHome">HOME</button>
      <button   @click="goURL('/A02Attribute')">A02Attr</button>

      <!-- 객체 형태의 데이터 전달은 name 사용 -->
      <button   @click="goURL( {name: 'attrs'} )">A02Attr</button>
      <button   @click="goURL( {name: 'params', params: {no: 1006, name: 'PARAMS'}} )">Params</button>
      <button   @click="goURL( {name: 'query', query: {no: 1007, name: 'QUERY'}} )">Query</button>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    back: function(){
      this.$router.back();
      // this.$router.go(-1);
    },
    forward: function() {
      this.$router.forward();
      // this.$router.go(1);
    },
    goHome: function() {
      this.$router.push('/A01Bind');
    },
    goURL: function(url) {
      this.$router.push(url);
    },
  },
  created() {
    console.log(this.$router);
  },


  beforeRouteEnter: (/*to, from*/) => {
    const storage = window.sessionStorage;

    console.log('페이지 수준의 네이게이션 보호 => 이동 전');
    if (storage.getItem('tel')) return true;
    else return false;
  },
  beforeRouteLeave: function(/*to, from*/) {
    const storage = window.sessionStorage;

    console.log('페이지 수준의 네이게이션 보호 => 이동 후');
    if (storage.getItem('address')) return true;
    else return false;
  },
  beforeRouteUpdate: function(/*to, from*/) {
    const storage = window.sessionStorage;

    console.log('페이지 수준의 네이게이션 보호 => 값 변경후');
    if (storage.getItem('abc')) return true;
    else return false;
  },
}
</script>