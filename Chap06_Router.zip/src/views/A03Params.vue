<template>
  <div>
    <h3>A03 Params</h3>

    <div>
        Name: {{ $route.params.name }}<br>
        No: {{ no }} <br>
        Person: {{ person.name }}<br>
    </div>
  </div>
</template>

<script>
import contactlist from './data/ContactList';

export default {
  data: function() {
    return {
        contacts: contactlist.contacts,
    }
  },
  computed: {
    no() {
      return this.$route.params.no;
    },
    person() {
      // 넘어오는 값은 string
      return this.contacts.find(item => item.no === Number(this.$route.params.no))
    }
  },
  created: function(){
    console.log(this.$route);
  },
}
</script>
