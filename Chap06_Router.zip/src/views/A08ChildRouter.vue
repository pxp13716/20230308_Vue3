<template>
  <div>
    <h3>A08 Child Router</h3>

    <div>
      <RouterLink to="">INFO</RouterLink> | 
      <RouterLink to="/A08ChildRouter">INFO</RouterLink> | 
      <RouterLink to="/A08ChildRouter/way">WAY</RouterLink> | 
      <span v-for="contact in contacts" :key="contact.no">
        <RouterLink :to="{name: 'view', params: {no: contact.no}}">{{ contact.name }}</RouterLink> | 
      </span>
    </div>
    <br />

    <div>
      <RouterView></RouterView>
    </div>
  </div>
</template>

<script>
import { RouterLink, RouterView } from 'vue-router';
import contactlist from './data/ContactList';

export default {
    data: function () {
        return {
            contacts: contactlist.contacts,
        };
    },
    components: { RouterView, RouterLink }
};
</script>

<style>
</style>