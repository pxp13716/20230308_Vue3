import { createApp } from 'vue'
import App from './App.vue'

// 폴더 내부의 index 파일은 폴더 이름까지만 지정해도 로드된다
// routes에 기술된 path에 따른 이름과 어떤 컴퍼넌트와 매칭할 정보를 가지고 있는 파일
import router from './router';
import 'bootstrap/dist/css/bootstrap.min.css';

// 전역 세팅을 보통 여기서 한다.
// createApp(App).use(router).mount('#app')
const app = createApp(App);
app.use(router);
app.mount('#app')


