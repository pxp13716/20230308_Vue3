/* eslint-disable no-unused-vars */
import { createRouter, createWebHistory } from 'vue-router';
import A01Binding from './../views/A01Binding.vue';
import A02Attribute from './../views/A02Attribute.vue';
import A03Params from './../views/A03Params.vue';
import A04Props from './../views/A04Props.vue';
import A05Contact from './../views/A05Contact.vue';
import A05ContactChild from './../views/A05ContactChild.vue';
import A06Query from './../views/A06Query.vue';
import A07Push from './../views/A07Push.vue';

// lazy load로 변경. 클릭하면 그때 서버로부터 해당 컴퍼넌트를 불러온다
// import A08ChildRouter from './../views/A08ChildRouter.vue';
import CompanyInfo from './../components/CompanyInfo.vue';
import CompanyWay from './../components/CompanyWay.vue';
// import A09NotFound from './../views/A09NotFound.vue';

// main.js에 이 파일을 로드
const routes = [
  // link 1개당 1개씩 요청할 패스와 컴퍼넌트를 정의
  // name은 중복되지 않는 이름으로 할당해야 한다
  { path: '/', name: 'index', component: A01Binding },
  { path: '/A01Bind', name: 'bind', component: A01Binding },
  { path: '/A02Attribute', name: 'attrs', component: A02Attribute },

  // path base로 데이터 전달. ":변수명"은 패스와 변수명 역할을 동시에 한다
  /*
    path: '/A03Params/:no/:name' => /A03Params/1001/NolBu
      const no = '1001'; 
      const name = 'NolBu';

    path: '/A03Params/:no/data/:name' => /A03Params/1001/data/NolBu
  */
  { path: '/A03Params/:no/:name', name: 'params', component: A03Params },
  { path: '/A04Props/:no/:name', name: 'props', component: A04Props, props: true },

  // 응용 예제
  { path: '/A05Contact', name: 'contact', component: A05Contact },
  { path: '/A05ContactChild/:no', name: 'contactChild', component: A05ContactChild, props: true },

  // 주소줄의 query문을 이용한 데이터 전달
  // 여기서는 패스만 설정, 값은 router-link에서 할당한다
  { path: '/A06Query', name: 'query', component: A06Query },

  // 버튼을 이용하여 패스 이동
  {
    path: '/A07Push', name: 'push', component: A07Push,
    beforeEnter: (to, from) => {
      console.log('라우터 수준의 네이게이션 보호');
      if (storage.getItem('age')) return true;
      else return false;
    }

  },

  // 하위 라우터를 수성 (서브 메뉴 구성)
  {
    path: '/A08ChildRouter', name: 'child', component: () => import('./../views/A08ChildRouter.vue'),
    children: [
      // 상위 패스가 지정되면 기본 값으로 표시된다
      { path: '', name: 'info', component: CompanyInfo },
      // 패스를 설정할때 "way" 형태로 지정. 링크에서는 "/상위 패스/패스이름" 형태로 설정
      { path: 'way', name: 'way', component: CompanyWay },
      // 절대패스는 /상위 패스/패스이름 형태로 지정해야 한다
      { path: '/A08ChildRouter/view/:no', name: 'view', component: A05ContactChild, props: true },
    ]
  },

  // 위의 모든 패스와 매칭되지 않는 경우 => Not Found
  { path: '/:path(.*)', name: 'not', component: () => import('./../views/A09NotFound.vue') },

]


const router = createRouter({
  routes: routes,
  history: createWebHistory(),        // method
})
export default router;

const storage = window.sessionStorage;

storage.setItem('name', 'abc');
storage.setItem('age', 'abc');
storage.setItem('tel', 'abc');
storage.setItem('address', 'abc');

// storage.removeItem('name');

router.beforeEach((to, from) => {
  console.log('전역 수준의 네이게이션 보호 => IN');
  if (storage.getItem('name') === 'abc') return true;
  else return false;
});

router.beforeResolve((to, from) => {
  console.log('전역 수준의 네이게이션 보호 => 이동 전');
  if (storage.getItem('name') === 'abc') return true;
  else return false;
});

router.afterEach((to, from) => {
  console.log('전역 수준의 네이게이션 보호 => OUT');
})