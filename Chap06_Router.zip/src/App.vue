<template>
  <div class="m-3">
    <h1>Chap06 Router</h1>

    <router-link to="/">Index</router-link> | 
    <router-link to="/A01Bind">A01Bind</router-link> | 
    <router-link :to="{path: 'A01Bind'}">A01Path</router-link> | 
    <router-link :to="{name: 'bind'}">A01Name</router-link> | 
    <router-link to="/A02Attribute">A02Attribute</router-link> | 

    <router-link to="/A03Params/1001/NolBu">A03 1001</router-link> | 
    <router-link :to="{name: 'params', params: {no: 1002, name: 'HungBu'}}">A03 1002</router-link> | 

    <!-- props. 각 컴퍼넌트에서 props: ['no', 'name'] 형태로 참조 -->
    <router-link to="/A04Props/1003/NolBu">A04 1003</router-link> | 
    <router-link :to="{name: 'props', params: {no: 1004, name: 'HungBu'}}">A04 1004</router-link> |

    <router-link :to="{name: 'contact'}">A05Contact</router-link> |

    <router-link to="/A06Query?no=1005&name=BangJa&address=Seoul#TOP">A06Query</router-link> | 
    <router-link :to="{name: 'query', query: {no: 1006, name: 'HangDan', address: 'Busan'}, hash: '#BTM'}">A06Query</router-link> |

    <router-link :to="{name: 'push'}">A07Push</router-link> | 

    <!-- 상위 패스에 관련만 지정 -->
    <router-link :to="{name: 'child'}">A08ChildRouter</router-link> | 

    <router-link to="/ABC">ABC</router-link> | 
    <hr>

    <!-- router-link로 지정된 컴퍼넌트가 표시될 위치. 1개 이상 올 수 있다 -->
    <router-view></router-view>
  </div>
</template>

<script>
// npm i vue-router

export default {
  name: 'App',
  components: {
    
  }
}
</script>


<style scoped>
  a.router-link-active { color: orange; font-weight: bold;}
</style>