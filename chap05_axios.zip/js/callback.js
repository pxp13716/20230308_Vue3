/* eslint-disable no-unused-vars */
/* eslint-disable no-empty */

// 함수 내부의 처리가 종료된 후, 그 이후 처리를 함수 내부의 값을 이용해서 처리
function calc(x, y, cb) {
  const result = x + y;
  // console.log(cb, result);
  cb(result)
}

calc(10, 20, function (x) {
  console.log('callback function 1');
  console.log(x / 2);
});

calc(10, 20, function (x) {
  console.log('callback function 2');
  console.log(x * 2);
});
console.log('');

// 기간이 걸리는 작업
function sleep(ms) {
  const wakeup = Date.now() + ms;
  while (Date.now() < wakeup) { }
  return 2000
}

function one() {
  console.log('----------- start ---------------');
  const result = sleep(2000);    // ajax로 데이터 가져오는 시간

  console.log('one 결과 => ' + result);
  console.log('----------- end ---------------');
}
// one();

function two() {
  console.log('----------- start ---------------');

  setTimeout(function () {
    const result = 3000;
    console.log('two=> ' + result);
  }, 2000);

  console.log('----------- end ---------------');
}
// two();

let value = 0;
function three() {
  console.log('----------- start ---------------');

  setTimeout(function () {
    const result = 3000;
    value = result;
    console.log('three=> ' + result);
  }, 2000);

  console.log('----------- end ---------------');
}
// three();              // 0. 2초 후라면 3000이 찍히지만 확인할 수 없음
console.log(value);


function four(callback) {
  console.log('----------- start ---------------');

  setTimeout(function () {
    const result = 3000;
    callback(result);
    console.log('three=> ' + result);
  }, 2000);

  console.log('----------- end ---------------');
}
// four( (x) => {
//   console.log(x);
// })


// ES6 promise
function promiseTest(ms) {
  console.log('----------- start ---------------');
  const promise = new Promise((resolve, reject) => {
    if (ms < 1000) reject('시간이 너무 짧습니다.');
    else {
      setTimeout(() => {
        const result = 3000;
        resolve(result)
      }, ms)
    }
  });
  console.log('----------- end ---------------');
  return promise;
}

/*
promiseTest(3000)
  .then((data) => {                             // 이 내부 함수가 resolve에 전달되는 값
    console.log(data);

    return promiseTest(data);         // 다음 then이 받아 처리한다
  })
  .then((data) => {
    console.log(data);
  })
  .catch((error) => { console.error(error) })  // 이 내부 함수가 reject에 전달되는 값

*/

// ES 2017 
// async ~ await 구문
// 항상 함수 형태로 묶어서 실행한다.
// await가 걸린 시간이 걸리는 작업은 결과 값이 떨어질때까지 대기 상태가 된다 (동기 처리)
// await가 함수 내부에 1개라도 있으면 그 바깥쪽 함수는 반드시 async가 걸려야 한다

async function getPromise() {
  try {
    console.log('----------- start ---------------');
    const result = await promiseTest(2000);
    console.log('Data 1 => ' + result);

    const value = await promiseTest(result);
    console.log('Data 2 => ' + value);

    console.log('----------- end ---------------');
  } catch (error) {
    // await 구문에서 에러가 발생하면 throw new Error(..)를 발생시킨다
    console.error(error);
  }
}
getPromise()

console.log('----------- 프로그램 종료 ---------------');