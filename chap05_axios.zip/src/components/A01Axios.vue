<template>
  <div>
    <h3>A01 Axios</h3>

    <div>
      <button @click="getContactList">Get ContactList</button>
      <button @click="getContactListAsync">Get ContactList Async</button>
      <button @click="getContact">Get Contact</button>
      <button @click="addContact">Add Contact</button>
      <button @click="updateContact">Update Contact</button>
      <button @click="deleteContact">Delete Contact</button>
    </div>

    <div>
      <textarea cols="100" rows="10" readonly :value="data"></textarea>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

// https://sample.bmaster.kro.kr/contacts/
const baseURL = 'http://localhost:8000/contacts/'

export default {
  data: function() {
      return { data: {} }
  },
  methods: {
    getContactList: function() {
      // axios.get(url, {options....})
      axios.get(baseURL, 
        { params: {pageno: 1, pagesize: 10}, 
          headers: {'content-type': 'application/json'}
        })
        .then( (resp) => {
          // console.log(resp.data);
          this.data = JSON.stringify(resp.data, '', 4);
        })
        .catch( (error) => console.error(error) )
    },
    getContactListAsync: async function() {
      try {
        const resp = await axios.get(baseURL, {params: {pageno: 2, pagesize: 10}});
        this.data = JSON.stringify(resp.data, '', 4);
      }catch(error) {
        console.error(error);
      }
    },
    getContact: function() {
      axios({
        methods: 'GET',
        url: baseURL + 100,
        params: {},
        headers: {}
      })
      .then( (resp) => {
        this.data = JSON.stringify(resp.data, '', 4);
      })
      .catch( (error) => console.error(error) )
    },
    addContact: function() {
      const data = {
          "name":"강감찬",
          "tel":"010-2222-3339",
          "address":"서울시"
      }

      // axios.post(url, 전달할 값, options.)
      axios.post(baseURL, data, {headers: {'content-type': 'application/json'}})
        .then( (resp) => {
          this.data = JSON.stringify(resp.data, '', 4);
        })
        .catch( (error) => console.error(error) )
    },
    updateContact: function() {
      const data = {
          "no": 1678422717694,
          "name":"이순신",
          "tel":"010-2222-1111",
          "address":"서울시"
      }

      // axios.put(url, 전달할 값, options.)
      axios.put(baseURL + 1678422717694, data, {headers: {'content-type': 'application/json'}})
        .then( (resp) => {
          this.data = JSON.stringify(resp.data, '', 4);
        })
        .catch( (error) => console.error(error) )
    },
    deleteContact: function() {
      // axios.delete(url, options.)
      axios.delete(baseURL + 1678422717694)
        .then( (resp) => {
          this.data = JSON.stringify(resp.data, '', 4);
        })
        .catch( (error) => console.error(error) )
    },
  }
}
</script>