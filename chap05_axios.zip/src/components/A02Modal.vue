<template>
  <div>
    <table class="table">
      <thead>
        <tr><th>No</th><th>Name</th><th>Tel</th><th>Address</th><th>Photo</th></tr>
      </thead>
      <tbody>
        <tr v-for="contact in contactList.contacts" :key="contact.no">
          <td>{{ contact.no }}</td>
          <td><a href="#"               @click="getContact(contact.no)">{{ contact.name }}</a></td>
          <td>{{ contact.tel }}</td>
          <td>{{ contact.address }}</td>
          <td><img  v-bind:src="contact.photo" alt="사진" width="50"></td>
        </tr>
      </tbody>
    </table>
    <button class="btn btn-primary"   @click="viewAdd">ADD</button>

    <!-- Get Contact Modal -->
    <div class="modal fade" id="getContent" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Get Contact</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              Name: <input type="text" class="form-control" disabled      :value="contact && contact.name"/>
              Tel: <input type="text" class="form-control" disabled       :value="contact.tel"/>
              Address: <input type="text" class="form-control" disabled   :value="contact.address"/>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary"     @click="deleteContact(contact.no)">Delete</button>
            <button type="button" class="btn btn-primary"     @click="viewUpdate">Update</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Update Contact Modal -->
    <div class="modal fade" id="updateContent" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Update Contact</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              Name: <input type="text" class="form-control"       v-model.trim="contact.name"/>
              Tel: <input type="text" class="form-control"        v-model.trim="contact.tel"/>
              Address: <input type="text" class="form-control"    v-model.trim="contact.address"/>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary"         @click="updateContact(contact)">Update</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Add Contact Modal -->
    <div class="modal fade" id="addContent" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Add Contact</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              Name: <input type="text" class="form-control"       v-model.trim="contact.name"/>
              Tel: <input type="text" class="form-control"        v-model.trim="contact.tel"/>
              Address: <input type="text" class="form-control"    v-model.trim="contact.address"/>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary"   @click="addContact(contact)">ADD</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import * as bootstrap from 'bootstrap/dist/js/bootstrap.esm.js'
import axios from 'axios';

const baseURL = 'http://localhost:8000/contacts/';

export default {
  data() {
    return {
      getContentModal: '',
      updateContentModal: '',
      addContentModal: '',
      // 값이 넘어오지 않을 경우 없는 객체를 참조하면 에러이므로 에러가 발생하지 않도록 기본값으로 초기화
      contactList: { pageno: '', pagesize: '', totalcount: '', contacts: {} },
      contact: {id: '', name: '', tel: '', address: '', photo: ''}
    }
  },
  methods: {
    async getContactList(no = 1, size = 10) {
      try {
        const resp = await axios.get(baseURL, {params: {pageno: no, pagesize: size}});
        this.contactList = resp.data;
      } catch(error) {
        console.error(error);
      }
    },
    async getContact(no) {
      this.getContentModal.show();
      try {
        const resp = await axios.get(baseURL + no);
        this.contact = resp.data;
      } catch(error) {
        console.error(error);
      }
    },
    async deleteContact(no) {
      try {
        const resp = await axios.delete(baseURL + no);
        console.log(resp);
       
        this.getContactList();        // 변경된 사항을 다시 로드. 기본값이 있음
        this.getContentModal.hide();  // modal 창 닫기
      } catch(error) {
        console.error(error);
      }
    },
    async updateContact(contact) {
      try {
        await axios.put(baseURL + contact.no, contact);
       
        this.getContactList();            // 변경된 사항을 다시 로드. 기본값이 있음
        this.updateContentModal.hide();   // modal 창 닫기
      } catch(error) {
        console.error(error);
      }
    },
    async addContact(contact) {
      try {
        await axios.post(baseURL, contact);
       
        this.getContactList();            // 변경된 사항을 다시 로드. 기본값이 있음
        this.addContentModal.hide();      // modal 창 닫기
      } catch(error) {
        console.error(error);
      }
    },
    viewUpdate() {
      this.getContentModal.hide()
      this.updateContentModal.show();
    },
    viewAdd(){
      // 다른 게시물을 본 상태라면 값이 들어가 있으니 그 값을 비우고 창 띄우기
      this.contact = {id: '', name: '', tel: '', address: '', photo: ''}
      this.addContentModal.show();
    },
  },
  mounted() {
    this.getContentModal = new bootstrap.Modal(document.getElementById('getContent'), {
      keyboard: false
    });
    this.updateContentModal = new bootstrap.Modal(document.getElementById('updateContent'), {
      keyboard: false
    });
    this.addContentModal = new bootstrap.Modal(document.getElementById('addContent'), {
      keyboard: false
    });

    // 시작하자마자 요청해서 데이터를 출력
    this.getContactList(1, 10);
  }
}
</script>
